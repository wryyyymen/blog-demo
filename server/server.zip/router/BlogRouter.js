const express = require("express")
const router = express.Router()
const {db,genid} = require("../db/DBUtils")



//删除博客
//查询博客
router.get("/search",async (req,res) => {

    let {keyword,categoryId,page,pagesize} = req.query

    page = page == null ? 1: page ;
    pagesize = pagesize == null ? 10 : pagesize
    categoryId = categoryId == null ? 0 : categoryId
    keyword = keyword == null ? "" : keyword

    let params = [] 
    let whereSqls = []
    if (categoryId != 0 ){
        whereSqls.push(" `category_id` = ?  ")
        params.push(categoryId)
    }

    if(keyword != ""){
        whereSqls.push(" (`title` LIKE ? OR `content` LIKE ?)")
        params.push("%"+keyword+"%")
        params.push("%"+keyword+"%")
    }

    let whereSqlstr = ""
    if(whereSqls.length > 0){
        whereSqlstr = "WHERE" + whereSqls.join("AND")
        //whereSqlstr = "WHERE `category_id` = ? AND `title` LIKE ? OR  `content` LIKE ?"
        //params = [categoryId,%keyword%,%keyword%]
    }

    //查询分页数据
    let searchSql = "SELECT * FROM `blog`"+whereSqlstr + "ORDER BY `create_time` DESC LIMIT ?,?"
    let searchSqlParams = params.concat([(page - 1) * pagesize,pagesize])

    
    let searchCount = "SELECT count(*) FROM `blog` WHERE" + whereSqls ; 
    let searchCountParams = params

    let searchResult = await db.async.all(searchSql,searchSqlParams)
    let countResult = await db.async.all(searchCount,searchCountParams)
    console.log(searchSql);

    if(searchResult.err == null && countResult.err == null){
        res.send({
            code:200,
            msg:'查询成功',
            data:{
                keyword,
                categoryId,
                page,
                pagesize,
                rows:searchResult.rows,
                count:countResult.rows[0]["count(*)"],
            }
        })
    }else{
        res.send({
            code:500,
            msg:"查询失败",
        })
    }

    //[" `category_id` = ? "," `title` LIKE ? OR `content` LIKE ? "]
 
    /** 
     * keyword 关键字
     * categoryId 分类编号
     * 
     * 分页：
     * page 页码
     * pagesize 分页大小
    */
})

//添加博客
router.post("/add",async (req,res) => {
    let {title,categoryId,content} = req.body;
    let id =  genid.NextId();
    let create_time = new Date().getTime();

    const insert_sql = "INSERT INTO `blog`(`id`,`title`,`category_id`,`content`,`create_time`) VALUES (?,?,?,?,?)"
    let params = [id,title,categoryId,content,create_time]

    let {err,rows} = await db.async.run(insert_sql,params)

    if(err == null){
        res.send({
            code:200,
            message:'添加成功',
            info:rows
        })
    }else{
        res.send({
            code:500,
            message:"post fail"
        })
    }
})

//修改博客`
router.put("/update",async (req,res) => {
    let {title,categoryId,content,id} = req.body;
    let create_time = new Date().getTime();

    const update_sql = "UPDATE `blog` SET  `title` = ?, `content` = ? ,`category_id` = ? WHERE  `id` = ? "
    let params = [title,content,categoryId,id]
    

    let {err,rows} = await db.async.run(update_sql,params)
    
    if(err == null){
        res.send({
            code:200,
            message:'修改成功',
            info:rows
        })
    }else{
        res.send({
            code:500,
            message:"post fail",
            err
        })
    }
})

//删除接口
router.delete("/delete",async (req,res)=>{
    let {id,name} = req.query.id
    const delete_sql = "DELETE FROM `category` WHERE  `id`=?"
    let {err,rows} = db.async.run(delete_sql,[name,id])

    if(err == null){
        res.send({
            code:200,
            message:'添加成功'
        })
    }else{
        res.send({
            code:500,
            message:"post fail"
        })
    }
})

module.exports = router