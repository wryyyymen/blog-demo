<template>
    <n-tabs type="line" animated justify-content="space-evenly" default-value="add">
        <n-tab-pane name="oasis" tab="Oasis">
            Wonderwall
        </n-tab-pane>
        <n-tab-pane name="add" tab="添加文章">
            <n-form>
                <n-form-item label="标题">
                    <n-input v-model:value="addArticle.title" placeholder="请输入标题"></n-input>
                </n-form-item>
                <n-form-item label="内容">
                    <rich-text-editor v-model="addArticle.content"></rich-text-editor>
                </n-form-item>
            </n-form>
        </n-tab-pane>
        <n-tab-pane name="jay chou" tab="周杰伦">
            七里香
        </n-tab-pane>
    </n-tabs>
    {{addArticle.content}}
</template>

<script setup>
import { AdminStore } from '../../stores/AdminStore';
import { ref, reactive, inject, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import RichTextEditor from '../../components/RichTextEditor.vue'
const router = useRouter()
const route = useRoute()

const message = inject("message")
const axios = inject("axios")
const dialog = inject("dialog")

const adminStore = AdminStore()

const addArticle = reactive({
    categoryId:0,
    title:"",
    content:"",
})
</script>

<style lang="scss" scoped>
.card-tabs .n-tabs-nav--bar-type {
    padding-left: 4px;
}
</style>